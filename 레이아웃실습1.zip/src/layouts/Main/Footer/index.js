/* src/layouts/Main/Footer/index.js */
export { default } from './Footer';