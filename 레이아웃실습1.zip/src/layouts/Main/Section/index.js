/* src/layouts/Main/Section/Section.js */
export { default } from './Section';