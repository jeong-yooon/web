/* src/layouts/Main/SideBar/SideBarNav/index.js */
export { default } from './SideBarNav';