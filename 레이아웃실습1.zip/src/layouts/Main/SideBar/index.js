/* src/layouts/Main/SideBar/index.js */
export { default } from './SideBar';