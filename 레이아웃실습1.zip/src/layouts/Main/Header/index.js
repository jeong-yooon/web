/* src/layouts/Main/Header/index.js */
export { default } from './Header';