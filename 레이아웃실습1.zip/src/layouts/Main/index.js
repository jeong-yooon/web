/* src/layouts/Main/index.js */
export { default } from './Main';