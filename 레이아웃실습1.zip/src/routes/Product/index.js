/* src/routes/Product/index.js */
export { default } from './Product';