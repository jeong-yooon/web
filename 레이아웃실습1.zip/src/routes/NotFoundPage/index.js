/* src/routes/NotFoundPage/index.js */
export { default } from './NotFoundPage';