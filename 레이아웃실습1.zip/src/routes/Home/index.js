/* src/routes/Home/index.js */
export { default } from './Home';