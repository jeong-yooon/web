/* src/routes/Board/index.js */
export { default } from './Board';