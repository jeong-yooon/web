// import './App.css';

import React from 'react';
import { BrowserRouter as Router, Switch, Redirect } from 'react-router-dom';

import RouteWithLayout from './layouts/RouteWithLayout';
import MainLayout from './layouts/Main';

import Home from './routes/Home';
import Board from './routes/Board';
import Product from './routes/Product';
import NotFoundPage from './routes/NotFoundPage';

// class Login extends React.Component{
//   constructor(){
//     super()
//     this.state = {id: "로그인 완료"}
//   }

//   render(){
//     return(
//         <div>
//             <Input onChange = { (e) => this.setState({id: e.target.value})}/>
//             <Button onClick = {(event) => {
//                 alert(this.state.id)
//             }}> Login </Button>
//         </div>
//     )
// }
// }

function App() {
  return (
    <Router>
      <Switch>
        <Redirect
          exact
          from="/"
          to="/home"
        />
        <RouteWithLayout
          path="/home"
          layout={ MainLayout }
          component={ Home }
        />
        <RouteWithLayout
          path="/board"
          layout={ MainLayout }
          component={ Board }
        />
        <RouteWithLayout
          path="/product"
          layout={ MainLayout }
          component={ Product }
        />
        <RouteWithLayout
          path="/not-found"
          layout={ MainLayout }
          component={ NotFoundPage }
        />
        <Redirect to="/not-found" />
      </Switch>
    </Router>
  );
}


  // return (
  //   <div className="App">
  //     <header className="App-header">
  //       <img src={logo} className="App-logo" alt="logo" />
  //       <p>
  //         Edit <code>src/App.js</code> and save to reload.
  //       </p>
  //       <a
  //         className="App-link"
  //         href="https://reactjs.org"
  //         target="_blank"
  //         rel="noopener noreferrer"
  //       >
  //         Learn React
  //         {/* 지현이의 테스트입니다. */}
  //         {/* 정윤이의 테스트입니다. */}
          
  //       </a>
  //     </header>
  //   </div>
  // );
// }

export default App;
