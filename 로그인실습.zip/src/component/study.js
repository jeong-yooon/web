import React from 'react';

class study extends React.Component{
    render(){
        return (
            <>
                
            </>
        );
    }
}

export default study;