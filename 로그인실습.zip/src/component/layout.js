import React from 'react';

class layout extends React.Component{
    render(){
        return (
            <>
                
            </>
        );
    }
}