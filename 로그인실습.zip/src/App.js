import React from "react";
import logo from './logo.svg';
import './App.css';
import {Button, Progress} from 'semantic-ui-react'
import { Icon } from 'semantic-ui-react'
import {Segment, Input } from 'semantic-ui-react'

class Login extends React.Component{
  constructor(){
    super()
    this.state = {id: "로그인 완료"}
  }

  render(){
    return(
        <div>
            <Input onChange = { (e) => this.setState({id: e.target.value})}/>
            <Button onClick = {(event) => {
                alert(this.state.id)
            }}> Login </Button>
        </div>
    )
}
}

function App() {
  return (
    <div>
      <h1> 아이디를 입력해 주세요.</h1>
      <Login/>
    </div>
  );

  // return (
  //   <div className="App">
  //     <header className="App-header">
  //       <img src={logo} className="App-logo" alt="logo" />
  //       <p>
  //         Edit <code>src/App.js</code> and save to reload.
  //       </p>
  //       <a
  //         className="App-link"
  //         href="https://reactjs.org"
  //         target="_blank"
  //         rel="noopener noreferrer"
  //       >
  //         Learn React
  //         {/* 지현이의 테스트입니다. */}
  //         {/* 정윤이의 테스트입니다. */}
          
  //       </a>
  //     </header>
  //   </div>
  // );
}

export default App;
